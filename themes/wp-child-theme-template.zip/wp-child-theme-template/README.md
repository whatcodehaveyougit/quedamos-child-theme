## Child Theme Template

This is a child theme template which you can use for you WordPress site.  Simply change the template in the style.css file to match the parent theme.

This child theme uses parcel to compile the scss and js assets. Please see the package.json for the commands in order to build these assets for production and to have them rebuild automatically when developing.