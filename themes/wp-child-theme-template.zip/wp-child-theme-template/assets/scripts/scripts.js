// import './js/general.js';
import './js/animations/count-up.js';
import './js/animations/zoom-in.js';
import './js/animations/slide-up.js';
