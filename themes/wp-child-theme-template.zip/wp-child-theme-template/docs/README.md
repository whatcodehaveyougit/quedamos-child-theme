Breakpoints

Mobile - 576px

Ipad - 781px

992px - Desktop

1200px - Large Screen